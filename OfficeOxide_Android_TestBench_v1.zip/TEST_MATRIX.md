# Real-device test matrix

Basic:
- [ ] Open simple XLSX
- [ ] Edit B17
- [ ] Save copy
- [ ] Reopen copy
- [ ] Original unchanged

Preservation:
- [ ] formulas
- [ ] styles/number formats
- [ ] merged cells
- [ ] freeze panes
- [ ] hidden rows/columns
- [ ] conditional formatting
- [ ] data validation
- [ ] images/charts
- [ ] print area/page breaks/margins/scaling

Stress:
- [ ] 1k rows
- [ ] 10k rows
- [ ] 50k rows
- [ ] 100k rows

Safety:
- [ ] corrupt XLSX
- [ ] malformed XLSX
- [ ] unsupported feature

Decision: GREEN = lock candidate; YELLOW = limitations/hybrid; RED = reject.

use jni::objects::{JClass, JString};
use jni::sys::jstring;
use jni::JNIEnv;
use office_oxide::edit::EditableDocument;
use office_oxide::xlsx::edit::CellValue;

fn msg(env: &mut JNIEnv, text: String) -> jstring {
    env.new_string(text).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}

#[no_mangle]
pub extern "system" fn Java_com_example_officeoxidetestbench_MainActivity_runXlsxTest(
    mut env: JNIEnv, _class: JClass, input: JString, output: JString
) -> jstring {
    let input: String = match env.get_string(&input) {
        Ok(v) => v.into(), Err(e) => return msg(&mut env, format!("FAIL: input path: {e}"))
    };
    let output: String = match env.get_string(&output) {
        Ok(v) => v.into(), Err(e) => return msg(&mut env, format!("FAIL: output path: {e}"))
    };
    let mut wb = match EditableDocument::open(&input) {
        Ok(v) => v, Err(e) => return msg(&mut env, format!("FAIL: open: {e}"))
    };
    if let Err(e) = wb.set_cell(0, "B17", CellValue::String("TEST_OK".into())) {
        return msg(&mut env, format!("FAIL: set B17: {e}"));
    }
    if let Err(e) = wb.save(&output) {
        return msg(&mut env, format!("FAIL: save copy: {e}"));
    }
    match EditableDocument::open(&output) {
        Ok(_) => msg(&mut env, "PASS: open → edit B17 → save copy → reopen succeeded.".into()),
        Err(e) => msg(&mut env, format!("FAIL: reopen saved copy: {e}"))
    }
}

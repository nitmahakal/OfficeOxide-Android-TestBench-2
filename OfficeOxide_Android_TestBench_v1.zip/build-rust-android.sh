#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/rust"
: "${ANDROID_NDK_HOME:?ANDROID_NDK_HOME is required}"
cargo ndk -t arm64-v8a -o "$ROOT/app/src/main/jniLibs" build --release

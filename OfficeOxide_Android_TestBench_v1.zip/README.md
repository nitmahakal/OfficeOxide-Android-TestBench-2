# OfficeOxide Android Test Bench v1

Technology-proof app for Android ARM64:
XLSX -> open -> edit B17 -> save COPY -> reopen.

OfficeOxide is pinned to 0.1.8.
This is not the final document app.

OfficeOxide 0.1.8 is published by its project under MIT/Apache-2.0.
This test bench is not final legal approval. Before shipping, audit exact bundled
version, all transitive dependencies, license/NOTICE requirements, fonts/assets,
and future rendering libraries.

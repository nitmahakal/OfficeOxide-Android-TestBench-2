plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.officeoxidetestbench"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.officeoxidetestbench"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        ndk { abiFilters += "arm64-v8a" }
    }
    sourceSets["main"].jniLibs.srcDir("src/main/jniLibs")
    buildTypes { release { isMinifyEnabled = false } }
}
tasks.register<Exec>("buildRustArm64") {
    workingDir(project.projectDir.parentFile)
    commandLine("bash", "build-rust-android.sh")
}
tasks.named("preBuild") { dependsOn("buildRustArm64") }

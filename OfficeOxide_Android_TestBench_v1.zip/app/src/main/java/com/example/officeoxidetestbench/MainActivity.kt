package com.example.officeoxidetestbench

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    private lateinit var status: TextView
    companion object {
        private const val PICK_XLSX = 1001
        init { System.loadLibrary("office_test") }
    }
    external fun runXlsxTest(inputPath: String, outputPath: String): String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "OfficeOxide XLSX Test Bench v1"; textSize = 22f
        })
        root.addView(Button(this).apply {
            text = "Choose XLSX"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }, PICK_XLSX)
            }
        })
        status = TextView(this).apply { text = "Waiting for an XLSX file…"; textSize = 16f }
        root.addView(status)
        setContentView(root)
    }

    @Deprecated("Minimal test-bench API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != PICK_XLSX || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val input = File(cacheDir, "input.xlsx")
            contentResolver.openInputStream(uri).use { src ->
                requireNotNull(src); input.outputStream().use { dst -> src.copyTo(dst) }
            }
            val output = File(externalCacheDir ?: cacheDir, "OfficeOxide_TestCopy.xlsx")
            status.text = "Running native XLSX test…"
            status.text = runXlsxTest(input.absolutePath, output.absolutePath) +
                "\n\nOriginal file was not modified.\nCopy: ${output.absolutePath}"
        } catch (e: Exception) {
            status.text = "FAIL\n${e.javaClass.simpleName}: ${e.message}"
        }
    }
}
